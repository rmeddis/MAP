function experiment=OHIOthresholds(experiment)

experiment.OHIOfrequencies=[494, 663, 870, 1125, 1442, 1838, 2338, 2957, 3725, 4680, 5866,  7334]; %Hz.
% User must specify abs thresholds (dB SPL) of each tone frequency
experiment.OHIOthresholds= [
    9.1	8.6	8.1	7.9	9.8	10.5	13.5	15.0	17.4	19.4	22.6	25.2
];